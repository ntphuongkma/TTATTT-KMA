

def isPrime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def isPrimePower(n, p):
    if n == 1:
        return True
    if n % p != 0:
        return False
    return isPrimePower(n // p, p)


def main():
    n = int(input("Nhap n: "))
    for i in range(1, n):
        if isPrimePower(i, n):
            print(i)


main()
