def T_prime(n):
    count = 0
    for i in range(1, n + 1):
        if n % i == 0:
            count += 1
    if count == 3:
        return True
    return False


def main():
    n = int(input())
    for i in range(1, n + 1):
        if T_prime(i):
            print(i)


main()
