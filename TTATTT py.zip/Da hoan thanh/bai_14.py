# Write a program to find a three-digit prime number, knowing that if we write the number in reverse order, we get a number that is the cube of a natural number.


def isPrime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def isCube(n):
    for i in range(1, n):
        if i ** 3 == n:
            return True
    return False


def reverse(n):
    return int(str(n)[::-1])


def main():
    for i in range(100, 1000):
        if isPrime(i) and isCube(reverse(i)):
            print(i)


main()
