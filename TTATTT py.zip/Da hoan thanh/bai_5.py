# Viết chương trình tính tổng của các số nguyên tố nằm trong khoảng [A, B] với A, B nhập vào từ bàn phím.

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def sum_prime(a, b):
    sum = 0
    for i in range(a, b+1):
        if is_prime(i):
            sum += i
    return sum


def main():
    a = int(input())
    b = int(input())
    print(sum_prime(a, b))


main()
