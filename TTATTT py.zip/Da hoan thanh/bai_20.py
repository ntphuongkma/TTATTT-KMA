# In ra các cặp số (A,B) nằm trong khoảng (M,N) sao cho ước số chung lớn nhất của A và B có giá trị là một số D cho trước. Với M,N,D nhập vào từ bàn phím. (0<M,N, D < 1000).


def ucln(a, b):
    while a != b:
        if a > b:
            a = a - b
        else:
            b = b - a
    return a


def main():
    M = int(input("Nhap M: "))
    N = int(input("Nhap N: "))
    D = int(input("Nhap D: "))
    for i in range(M, N + 1):
        for j in range(M, N + 1):
            if ucln(i, j) == D:
                print(i, j)


main()
