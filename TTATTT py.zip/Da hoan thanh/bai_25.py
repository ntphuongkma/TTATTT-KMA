# Cho 2 số M và N thoả mãn điều kiện: 1<=N<=10000; 2<M<=100; Hãy viết chương trình xác định xem số N có thể được phân tích thành tổng của M số nguyên tố hay không? Nếu có thì in ra các số đó.


def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def find_prime(n, m):
    result = []
    for i in range(2, n):
        if is_prime(i):
            result.append(i)
    return result


def check(n, m):
    result = find_prime(n, m)
    if len(result) < m:
        return False
    for i in range(m):
        n -= result[i]
    if n == 0:
        return True
    return False


def main():
    n = int(input("Nhap n: "))
    m = int(input("Nhap m: "))
    if check(n, m):
        print("Co the phan tich")
    else:
        print("Khong the phan tich")


main()
