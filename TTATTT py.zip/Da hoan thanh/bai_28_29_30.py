#  Viết chương trình đếm số các số Carmichael (là các số giả nguyên tố n thoả mãn điều kiện là hợp số và thoả mãn b^(n-1)≡1 (mod n) với mọi số nguyên dương b nguyên tố cùng nhau với n) nhỏ hơn một số N cho trước nhập vào từ bàn phím (với điều kiện 0≤N≤10000.

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def is_carmichael(n):
    if is_prime(n):
        return False
    for b in range(2, n):
        if is_prime(b):
            if pow(b, n - 1, n) != 1:
                return False
    return True


def count_carmichael(n):
    count = 0
    for i in range(2, n):
        if is_carmichael(i):
            count += 1
    return count


n = int(input())
print(count_carmichael(n))
