# Viết chương trình in ra các số nguyên dương x nằm trong khoảng [m,l] sao cho giá trị của biểu thức Ax^2+Bx+C là một số nguyên tố. Với A,B,C, m,l là các số nguyên nhập từ bàn phím (m<l).


def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def main():
    a = int(input("a = "))
    b = int(input("b = "))
    c = int(input("c = "))
    m = int(input("m = "))
    l = int(input("l = "))
    if m < l:
        for i in range(m, l + 1):
            if is_prime(a * i * i + b * i + c):
                if i > 0:
                    print(i)


main()
