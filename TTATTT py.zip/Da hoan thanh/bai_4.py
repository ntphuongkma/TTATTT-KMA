# Viết chương trình đếm số số nguyên tố nằm trong khoảng [A,B] với A, B nhập vào từ bàn phím


def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def count_prime(a, b):
    count = 0
    for i in range(a, b + 1):
        if is_prime(i):
            count += 1
    return count


def main():
    a = int(input(""))
    b = int(input(""))
    print(count_prime(a, b))


main()
