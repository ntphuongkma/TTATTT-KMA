# Một số được gọi là số mạnh mẽ khi nó đồng thời vừa chia hết cho số nguyên tố và chia hết cho bình phương của số nguyên tố đó. Tìm số mạnh mẽ nhỏ hơn số N cho trước (N < 10000).


def isPrime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def isStrong(n):
    for i in range(2, n):
        if isPrime(i) and n % i == 0 and n % (i * i) == 0:
            return True
    return False


def main():
    n = int(input())
    if n < 10000:
        for i in range(2, n):
            if isStrong(i):
                print(i)


main()
