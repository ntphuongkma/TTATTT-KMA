# Hai số nguyên tố sinh đôi là hai số nguyên tố hơn kém nhau 2 đơn vị. Tìm hai số nguyên tố sinh đôi nhỏ hơn hoặc bằng N, với N được nhập vào từ bàn phím

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def main():
    n = int(input())
    for i in range(2, n + 1):
        if is_prime(i) and is_prime(i + 2):
            if i + 2 <= n:
                print(i, i + 2)
            else:
                break


main()
