def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def main():
    a = int(input("a = "))
    b = int(input("b = "))
    c = int(input("c = "))
    x = 0
    while True:
        if is_prime(a * pow(x, 2) + b * x + c):
            print("x =", x)
            break
        x += 1


main()
