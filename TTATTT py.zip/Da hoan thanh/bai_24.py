# Đặt S1, S2 là các mảng chứa giá trị bình phương của các số nguyên. Hãy viết chương trình in ra số lượng tất cả các số nguyên tố nằm trong khoảng [a,b] sao cho số này cũng là tổng của hai số x và y với x thuộc S1 và y thuộc S2. Trong đó, a,b là các số được nhập từ bàn phím. Ví dụ: với a=10, b =15, in ra giá trị là 1 vì trong khoảng [10,15] chỉ có 2 số nguyên tố 11 và 13, nhưng chỉ có 13 = 2^2 + 3^2=4+9.


def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def is_sum_of_squares(n, S1, S2):
    for x in S1:
        for y in S2:
            if x + y == n:
                return True
    return False


def main():
    a = int(input("a = "))
    b = int(input("b = "))
    S1 = [i**2 for i in range(1, b)]
    S2 = [i**2 for i in range(1, b)]
    count = 0
    for i in range(a, b):
        if is_prime(i) and is_sum_of_squares(i, S1, S2):
            count += 1
    print(count)


main()
