# kiểm tra số nguyên tố
def so_nguyen_to(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


# k : số các ước nguyên tố
def so_uoc_nguyen_to(n):
    count = 0
    for i in range(1, n + 1):
        if n % i == 0 and so_nguyen_to(i):
            count += 1
    return count


# q : tổng các ước số nguyên tố
def tong_uoc_nguyen_to(n):
    tong = 0
    for i in range(1, n + 1):
        if n % i == 0 and so_nguyen_to(i):
            tong += i
    return tong


# p : tổng các ước số
def tong_uoc(n):
    sum = 0
    for i in range(1, n + 1):
        if n % i == 0:
            sum += i
    return sum


# s : số các ước số
def so_uoc(n):
    count = 0
    for i in range(1, n + 1):
        if n % i == 0:
            count += 1
    return count


def main():
    N = int(input())
    if N > 0 and type(N) == int:
        k = so_uoc_nguyen_to(N)
        q = tong_uoc_nguyen_to(N)
        p = tong_uoc(N)
        s = so_uoc(N)
        print(N + p + s - q - k)


main()
