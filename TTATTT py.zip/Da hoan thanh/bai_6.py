# Hai số tạo thành một cặp số thân thiết khi chúng tuân theo quy luật: Số này bằng tổng tất cả các ước của số kia (trừ chính số đó) và ngược lại. Viết chương trình tìm hai số dạng này nhỏ hơn N (với N nhập vào từ bàn phím).


def is_friend_number(a, b):
    sum_a = 0
    sum_b = 0
    for i in range(1, a):
        if a % i == 0:
            sum_a += i
    for i in range(1, b):
        if b % i == 0:
            sum_b += i
    if sum_a == b and sum_b == a:
        return True
    return False


def main():
    n = int(input("Nhập n: "))
    for i in range(1, n):
        for j in range(i + 1, n):
            if is_friend_number(i, j):
                print(i, j)


main()
