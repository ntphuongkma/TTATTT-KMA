# Viết chương trình in ra màn hình YES trong trường hợp tổng của các số nguyên tố trong khoảng [A, B] là cũng là một số nguyên tố và NO nếu ngược lại. Với A,B là hai số được nhập vào từ bàn phím.


def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def sum_prime(a, b):
    sum = 0
    for i in range(a, b + 1):
        if is_prime(i):
            sum += i
    return sum


def main():
    a = int(input())
    b = int(input())
    sum = sum_prime(a, b)
    if is_prime(sum):
        print("YES")
    else:
        print("NO")
