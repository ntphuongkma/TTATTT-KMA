# Một số emirp là một số nguyên tố mà khi đảo ngược vị trí các chữ số của nó, ta cũng được một số nguyên tố. Viết chương trình liệt kê các số emirp nhỏ hơn N với N nhập vào từ bàn phím.


def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def reverse(n):
    return int(str(n)[::-1])


def is_emirp(n):
    if is_prime(n):
        if is_prime(reverse(n)):
            return True
    return False


def find_emirp(n):
    for i in range(2, n):
        if is_emirp(i):
            print(i)


n = int(input("Enter n: "))
find_emirp(n)
