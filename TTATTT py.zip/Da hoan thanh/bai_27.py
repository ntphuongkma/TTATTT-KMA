#  Viết chương trình in ra các cặp số (a,b) thoả mãn điều kiện 0<a,b<1000, sao cho ước chung lớn nhất của 2 số đó là một số nguyên tố.

def isPrime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def gcd(a, b):
    if a == 0:
        return b
    return gcd(b % a, a)


def findPrimeGCD():
    for a in range(1, 1000):
        for b in range(1, 1000):
            if gcd(a, b) in primes:
                print(a, b)


primes = [i for i in range(1000) if isPrime(i)]
findPrimeGCD()
