def so_nguyen_to(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def so_uoc_nguyen_to(n):
    count = 0
    for i in range(1, n + 1):
        if n % i == 0 and so_nguyen_to(i):
            count += 1
    return count


def so_uoc(n):
    count = 0
    for i in range(1, n + 1):
        if n % i == 0:
            count += 1
    return count


def main():
    n = int(input("Nhập n: "))
    print(f"Số ước nguyên tố: {so_uoc_nguyen_to(n)}")
    print(f"Số ước: {so_uoc(n)}")


main()
