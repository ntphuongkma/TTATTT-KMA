# Viết chương trình tìm các số nguyên tố từ một mảng sinh ngẫu nhiên có kích thước N, với N nhập vào từ bàn phím.

import random


def isPrime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def main():
    N = int(input("Nhập N: "))
    arr = [random.randint(2, N) for i in range(N)]
    print(arr)
    print([x for x in arr if isPrime(x)])


main()
