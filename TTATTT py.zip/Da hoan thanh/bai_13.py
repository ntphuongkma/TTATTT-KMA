# tìm hai số nguyên tố nhỏ hơn hoặc bằng N với N nhập vào từ bàn phím, sao cho tổng và hiệu của chúng đều là số nguyên tố.

def isPrime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def findPrime(n):
    for i in range(2, n+1):
        if isPrime(i):
            for j in range(i, n+1):
                if isPrime(j):
                    if isPrime(i+j) and isPrime(abs(j-i)):
                        return f"{i}, {j}"


n = int(input("Nhap n: "))
print(findPrime(n))
